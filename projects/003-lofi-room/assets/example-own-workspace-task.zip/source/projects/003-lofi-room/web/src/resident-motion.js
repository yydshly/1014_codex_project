import * as THREE from "three";
import { moveWithCollisions } from "./navigation.js";

export const BODY = { hip: 0.8, thigh: 0.35, shin: 0.34, upperArm: 0.28, forearm: 0.235, height: 1.9 };
const down = new THREE.Vector3(0, -1, 0);
const clamp = THREE.MathUtils.clamp;
const smooth = (value, target, delta, rate = 11) => THREE.MathUtils.damp(value, target, rate, delta);
function turn(actor, yaw, delta) {
  const difference = Math.atan2(Math.sin(yaw - actor.root.rotation.y), Math.cos(yaw - actor.root.rotation.y));
  actor.root.rotation.y += clamp(difference, -delta * 3.4, delta * 3.4);
}

export function advanceTeamActor(r, { delta, bounds, obstacles, reducedMotion, choreographed }) {
  const action = r.action;
  let distanceMoved = 0, sitting = 0, rising = false;
  if (r.finishDrinkAge != null) {
    r.finishDrinkAge += delta;
    const drinkAge = r.finishDrinkAge;
    if (drinkAge >= 6.2) r.finishDrinkAge = null;
    return { distanceMoved, sitting, rising, rootY: 0, settlingDrink: drinkAge };
  }
  if (action?.depart && (r.sitAmount || 0) > 0.035) {
    // Stand up before taking the first step away from the chair.
    rising = true;
    turn(r, r.sittingYaw ?? r.root.rotation.y, delta);
  } else {
    const docking = action?.depart || (!r.path?.length && action?.seat && !action.arrived);
    if (docking) {
      const destination = action.depart || action.seat;
      const dx = destination.x - r.root.position.x, dz = destination.z - r.root.position.z;
      const distance = Math.hypot(dx, dz), step = Math.min(distance, delta * 0.7);
      if (distance > 0.001) {
        r.root.position.x += dx / distance * step;
        r.root.position.z += dz / distance * step;
        distanceMoved = step;
      }
      if (!action.depart) {
        const total = Math.hypot(action.x - action.seat.x, action.z - action.seat.z);
        sitting = THREE.MathUtils.smoothstep(1 - distance / Math.max(0.1, total), 0.45, 0.98);
        turn(r, sitting > 0.25 ? action.yaw : Math.atan2(dx, dz), delta);
      } else turn(r, Math.atan2(dx, dz), delta);
      if (distance < 0.02) {
        if (action.depart) action.depart = null;
        else { action.arrived = true; r.sittingYaw = action.yaw; }
      }
    } else if (r.path?.length && (!reducedMotion || choreographed)) {
      const target = r.path[0], dx = target.x - r.root.position.x, dz = target.z - r.root.position.z;
      const distance = Math.hypot(dx, dz);
      if (distance < (r.path.length === 1 ? 0.001 : 0.035)) r.path.shift();
      else {
        const step = Math.min(distance, delta * (action?.pace ?? (choreographed ? 1.08 : 1.05)));
        const next = moveWithCollisions(r.root.position, dx / distance * step, dz / distance * step, bounds, obstacles, 0.19);
        distanceMoved = Math.hypot(next.x - r.root.position.x, next.z - r.root.position.z);
        r.root.position.x = next.x; r.root.position.z = next.z;
        turn(r, Math.atan2(dx, dz), delta);
      }
    }
  }
  if (action && !r.path?.length && !action.depart && !action.seat) action.arrived = true;
  if (action?.arrived) {
    action.age += delta;
    turn(r, action.yaw, delta);
    if (action.seat) { sitting = 1; r.seatedFloor = Boolean(action.seat.floor); }
  }
  return { distanceMoved, sitting, rising, rootY: (action?.depart ? r.seatedY : action?.seat?.y) ?? r.seatedY ?? -0.28 };
}

// Solve shoulder -> elbow -> wrist with a downward/outward elbow pole. The
// wrist then keeps the palm in the intended plane instead of following a rod.
function reach(r, index, point, alpha, palmAngle = -Math.PI / 2) {
  const shoulder = r.arms[index], elbow = r.elbows[index], wrist = r.wrists[index];
  const side = index ? 1 : -1;
  const target = new THREE.Vector3(...point);
  const handRotation = new THREE.Quaternion().setFromEuler(new THREE.Euler(palmAngle, 0, side * 0.04));
  const palmOffset = new THREE.Vector3(0, -0.055, 0).applyQuaternion(handRotation);
  target.sub(palmOffset);
  const direction = target.clone().sub(shoulder.position);
  const distance = clamp(direction.length(), 0.04, BODY.upperArm + BODY.forearm - 0.008);
  direction.normalize();
  const along = (BODY.upperArm ** 2 - BODY.forearm ** 2 + distance ** 2) / (2 * distance);
  const height = Math.sqrt(Math.max(0, BODY.upperArm ** 2 - along ** 2));
  const pole = new THREE.Vector3(side * 0.2, -1, -0.15);
  pole.addScaledVector(direction, -pole.dot(direction)).normalize();
  const elbowDirection = direction.clone().multiplyScalar(along).addScaledVector(pole, height);
  const upper = new THREE.Quaternion().setFromUnitVectors(down, elbowDirection.clone().normalize());
  const forearmDirection = direction.clone().multiplyScalar(distance).sub(elbowDirection).normalize().applyQuaternion(upper.clone().invert());
  const lower = new THREE.Quaternion().setFromUnitVectors(down, forearmDirection);
  const hand = upper.clone().multiply(lower).invert().multiply(handRotation);
  shoulder.quaternion.slerp(upper, alpha);
  elbow.quaternion.slerp(lower, alpha);
  wrist.quaternion.slerp(hand, alpha);
}

function groundedLeg(height, forward) {
  const distance = clamp(Math.hypot(height, forward), 0.05, BODY.thigh + BODY.shin - 0.0001);
  const hipOffset = Math.acos(clamp((BODY.thigh ** 2 + distance ** 2 - BODY.shin ** 2) / (2 * BODY.thigh * distance), -1, 1));
  const hip = -(Math.atan2(forward, height) + hipOffset);
  const knee = Math.PI - Math.acos(clamp((BODY.thigh ** 2 + BODY.shin ** 2 - distance ** 2) / (2 * BODY.thigh * BODY.shin), -1, 1));
  return [hip, knee];
}

export function updateResidentPose(r, state) {
  const { time, delta, reducedMotion, pose = "idle", distanceMoved = 0, sitting = 0, rising = false, speaking = false, level = 0, listening = false, floor = false, sleeping = false, dancing = false } = state;
  const alpha = reducedMotion ? 1 : 1 - Math.exp(-11 * delta);
  const motion = reducedMotion ? 0 : 1;
  r.sitAmount = smooth(r.sitAmount || 0, sitting, delta, 9);
  const sit = r.sitAmount;
  if (state.dynamicSeat) {
    r.root.position.y = smooth(r.root.position.y, state.rootY * sit, delta, 14);
    if (sitting === 1) r.seatedY = state.rootY;
  }
  r.gaitPhase = (r.gaitPhase || 0) + distanceMoved * Math.PI * 2 / 0.94;
  r.walkWeight = smooth(r.walkWeight || 0, distanceMoved > 0.001 && !rising ? 1 - sit : 0, delta, 10);
  r.voiceWeight = smooth(r.voiceWeight || 0, speaking ? level : 0, delta, 12);
  const walk = r.walkWeight * motion;
  const phase = r.gaitPhase, breath = Math.sin(time * 1.45 + r.index * 0.9) * motion;
  const age = state.poseAge ?? r.action?.age ?? 0;
  const drink = pose === "drink" && !rising && walk < 0.15;
  const lift = drink ? THREE.MathUtils.smoothstep(age, 1.2, 2.3) * (1 - THREE.MathUtils.smoothstep(age, 3.8, 4.8)) : 0;
  const reachCup = drink ? THREE.MathUtils.smoothstep(age, 0.15, 1) * (1 - THREE.MathUtils.smoothstep(age, 5.4, 6.2)) : 0;
  r.drinkGrip = drink ? THREE.MathUtils.smoothstep(age, 0.65, 1.1) * (1 - THREE.MathUtils.smoothstep(age, 5, 5.5)) : 0;
  r.drinkTilt = drink ? THREE.MathUtils.smoothstep(age, 2.4, 2.9) * (1 - THREE.MathUtils.smoothstep(age, 3.3, 3.8)) * 0.32 : 0;
  r.drinkLift = lift;
  const stretch = pose === "stretch" && !rising && walk < 0.15
    ? THREE.MathUtils.smoothstep(age, 0.35, 1.7) * (1 - THREE.MathUtils.smoothstep(age, 4, 5.5)) : 0;
  const working = ["type", "read", "write"].includes(pose);
  const leaning = rising ? 0.25 : stretch ? -0.065 * stretch : pose === "rest" ? -0.06 : pose === "type" ? (sit > 0.4 ? 0.11 : 0.14) : working ? 0.045 : 0.012;
  r.rig.rotation.x = sleeping ? -Math.PI / 2 : 0;
  r.rig.rotation.z = smooth(r.rig.rotation.z, dancing ? Math.sin(time * 1.7) * 0.035 * motion : 0, delta);
  r.rig.position.y = breath * 0.0025 + (-0.045 + Math.abs(Math.sin(phase * 2)) * 0.006) * walk;
  r.body.rotation.x = smooth(r.body.rotation.x, sleeping ? 0 : leaning, delta);
  r.body.rotation.z = smooth(r.body.rotation.z, sleeping || sit > 0.2 ? 0 : breath * 0.009 + Math.sin(phase) * 0.012 * walk, delta);
  r.body.position.x = smooth(r.body.position.x, sit > 0.2 ? 0 : breath * 0.006, delta);

  for (let i = 0; i < 2; i++) {
    const side = i ? 1 : -1, swing = Math.sin(phase + i * Math.PI);
    let hipX = -swing * 0.48 * walk - sit * 1.39;
    let kneeX = 0.04 + Math.max(0, swing) * 0.65 * walk + sit * 1.35;
    let hipZ = side * (0.018 + 0.025 * sit), hipY = 0;
    const planted = !floor && !sleeping && (sit > 0.003 || walk > 0.003 || rising);
    if (planted) {
      const cycle = ((phase + i * Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
      const progress = cycle / Math.PI;
      const forward = progress < 1 ? 0.22 - progress * 0.44 : -0.22 + THREE.MathUtils.smoothstep(progress - 1, 0, 1) * 0.44;
      const lift = progress > 1 ? Math.sin((progress - 1) * Math.PI) * 0.085 : 0;
      const ankleY = 0.11 + lift * walk;
      [hipX, kneeX] = groundedLeg(BODY.hip + r.root.position.y + r.rig.position.y - ankleY, sit * (state.footForward ?? 0.34) + forward * walk * (1 - sit));
    }
    if (floor) { hipX = -1.48; kneeX = 2.84; hipZ = side * 0.33; hipY = side * 0.42; }
    if (sleeping) { hipX = -0.03; kneeX = 0.08; hipZ = side * 0.015; }
    r.legs[i].rotation.x = planted ? hipX : smooth(r.legs[i].rotation.x, hipX, delta, 15);
    r.legs[i].rotation.z = smooth(r.legs[i].rotation.z, hipZ, delta);
    r.legs[i].rotation.y = smooth(r.legs[i].rotation.y, hipY, delta);
    r.knees[i].rotation.x = planted ? kneeX : smooth(r.knees[i].rotation.x, kneeX, delta, 15);
    const ankle = floor ? -0.85 : -(r.legs[i].rotation.x + r.knees[i].rotation.x) + Math.min(0, swing) * 0.16 * walk;
    r.ankles[i].rotation.x = planted ? ankle : smooth(r.ankles[i].rotation.x, ankle, delta, 16);
    r.ankles[i].rotation.y = smooth(r.ankles[i].rotation.y, side * 0.055, delta);

    const arm = r.arms[i], elbow = r.elbows[i], wrist = r.wrists[i];
    const speechGesture = speaking && i === 1 && !working && sit < 0.2;
    if (drink && i === 1) {
      const target = new THREE.Vector3(0.2, -0.015, 0.22).lerp(new THREE.Vector3(0.14, 0.145, 0.4), reachCup);
      target.lerp(new THREE.Vector3(0.14, 0.50, 0.32), lift);
      reach(r, i, target.toArray(), alpha, -Math.PI / 2);
    } else if (pose === "wave" && i === 1 && !rising && walk < 0.15) {
      reach(r, i, [0.32, 0.71, 0.16], alpha, -2.6);
      wrist.rotation.z += Math.sin(age * 6) * 0.025 * motion;
    } else if (stretch > 0.001) {
      const target = new THREE.Vector3(side * 0.25, -0.015, 0.09).lerp(new THREE.Vector3(side * 0.2, 1.04, 0.025), stretch);
      reach(r, i, target.toArray(), alpha, -Math.PI / 2 + stretch * Math.PI * 1.35);
    } else if (working && !rising && walk < 0.15) {
      const tap = pose === "type" ? Math.sin(time * 9 + i * Math.PI) * 0.007 * motion : 0;
      const hand = pose === "type"
        ? [side * 0.13, sit > 0.4 ? 0.41 + tap : 0.11 + tap, sit > 0.4 ? 0.43 : 0.37]
        : pose === "write" ? [side * 0.14, 0.08 + (i ? tap : 0), 0.4] : [side * 0.145, 0.30, 0.31];
      reach(r, i, hand, alpha, pose === "read" ? -1.9 : -Math.PI / 2 + tap * 3);
    } else if (["rest", "listen", "talk"].includes(pose) && sit > 0.4 && !rising) {
      reach(r, i, [side * 0.16, -0.015, 0.22], alpha, -Math.PI / 2);
    } else if (["offer", "receive"].includes(pose) && walk < 0.15) {
      reach(r, i, [side * 0.15, i || pose === "receive" ? 0.24 : 0.17, i || pose === "receive" ? 0.39 : 0.22], alpha, -1.5);
    } else if ((pose === "point" && i === 1 || speechGesture) && walk < 0.15) {
      const gesture = (Math.sin(time * 2.1) + 1) * 0.5 * motion;
      reach(r, i, pose === "point" && !speaking ? [0.34, 0.62, 0.34] : [0.28, 0.21 + gesture * 0.045, 0.25 + gesture * 0.025], alpha, -1.8);
    } else {
      const armX = sleeping ? -0.12 : Math.sin(phase + i * Math.PI) * 0.28 * walk - 0.045;
      arm.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(armX, 0, side * (dancing ? 0.15 + breath * 0.04 : 0.055))), alpha);
      elbow.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(sleeping ? -0.28 : -0.15 - 0.13 * walk, 0, 0)), alpha);
      wrist.quaternion.slerp(new THREE.Quaternion(), alpha);
    }
  }
  const nod = listening ? Math.sin(time * 1.8 + r.index) * 0.018 * motion : 0;
  const headX = sleeping ? 0 : drink ? -0.055 * lift : stretch ? -0.08 * stretch : pose === "read" ? 0.30 : pose === "write" ? 0.2 : pose === "type" ? -0.11 : nod + breath * 0.009;
  r.head.rotation.x = smooth(r.head.rotation.x, headX, delta);
  r.head.rotation.y = smooth(r.head.rotation.y, state.headYaw || 0, delta);
  r.head.rotation.z = smooth(r.head.rotation.z, sleeping ? -0.04 : 0, delta);
  r.head.position.z = smooth(r.head.position.z, sleeping ? 0.15 : 0, delta);
  const blink = (time + r.index * 1.41) % 5.7;
  const open = sleeping ? 0.12 : blink < 0.14 ? Math.abs(blink - 0.07) / 0.07 : 1;
  r.eyes.forEach((eye) => (eye.scale.y = 0.06 * open));
  r.eyeHighlights.forEach((highlight) => (highlight.visible = open > 0.4));
  r.mouth.scale.y = smooth(r.mouth.scale.y, 0.012 + r.voiceWeight * 0.04, delta, 18);
  if (r.document) r.document.visible = !rising && r.walkWeight < 0.15 && pose === "read";
  if (r.pen) r.pen.visible = !rising && r.walkWeight < 0.15 && pose === "write";
  r.root.updateMatrixWorld();
}
