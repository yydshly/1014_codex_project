import * as THREE from "three";
import { STATUS_TEXT } from "../shared/team.js";
import { BOARD } from "./stage-layout.js";
import { createWaterCorner } from "./daily-props.js";
export function createSharedSpace(scene, room) {
  const root = new THREE.Group();
  const waterCorner = new THREE.Group();
  scene.add(root, waterCorner);
  createWaterCorner(waterCorner);
  const board = new THREE.Mesh(
    new THREE.BoxGeometry(BOARD.width, 1.55, 0.12),
    new THREE.MeshStandardMaterial({ color: "#596759", roughness: 0.8 }),
  );
  board.position.set(BOARD.x, 1.9, BOARD.z);
  board.userData.workspaceAction = "board";
  root.add(board);
  const makeTexture = (w, h) => {
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    return { canvas, context: canvas.getContext("2d"), texture };
  };
  const white = makeTexture(1024, 540),
    terminal = makeTexture(1024, 576);
  const face = new THREE.Mesh(
    new THREE.PlaneGeometry(BOARD.width - 0.14, 1.4),
    new THREE.MeshBasicMaterial({ map: white.texture }),
  );
  face.position.set(BOARD.x, 1.9, BOARD.z + 0.067);
  face.userData.workspaceAction = "board";
  root.add(face);
  for (const offset of [-1, 1]) {
    const leg = new THREE.Mesh(
      new THREE.BoxGeometry(0.055, 1.2, 0.055),
      board.material,
    );
    leg.position.set(BOARD.x + offset, 0.65, BOARD.z);
    const foot = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.065, 0.5),
      board.material,
    );
    foot.position.set(BOARD.x + offset, 0.06, BOARD.z);
    root.add(leg, foot);
  }
  const laptop = new THREE.Group();
  laptop.position.set(0.85, 0.84, 0.6);
  laptop.rotation.y = Math.PI / 2;
  const base = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.035, 0.34),
    new THREE.MeshStandardMaterial({ color: "#567675" }),
  );
  const lid = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.33, 0.035),
    base.material,
  );
  lid.position.set(0, 0.17, -0.15);
  const smallScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.43, 0.26),
    new THREE.MeshBasicMaterial({ map: terminal.texture }),
  );
  smallScreen.position.set(0, 0.17, -0.13);
  smallScreen.userData.workspaceAction = "computer";
  laptop.add(base, lid, smallScreen);
  root.add(laptop);
  const notebook = new THREE.Mesh(
    new THREE.BoxGeometry(0.43, 0.014, 0.27),
    new THREE.MeshStandardMaterial({ color: "#e8dfc8" }),
  );
  notebook.position.set(0, 0.825, 1.1);
  root.add(notebook);
  for (let i = 0; i < 4; i++) {
    const line = new THREE.Mesh(
      new THREE.BoxGeometry(0.31, 0.002, 0.005),
      new THREE.MeshBasicMaterial({ color: "#91a39b" }),
    );
    line.position.set(0, 0.834, 1.02 + i * 0.05);
    root.add(line);
  }
  const computer = room.computer;
  computer.material.map = terminal.texture;
  computer.material.needsUpdate = true;
  computer.userData.workspaceAction = "computer";
  const wrap = (ctx, text, x, y, width, line = 35, maxLines = 2) => {
    let row = "",
      count = 0;
    for (const char of text || "") {
      if (ctx.measureText(row + char).width > width) {
        ctx.fillText(row, x, y + count * line);
        row = "";
        if (++count >= maxLines) return;
      }
      row += char;
    }
    ctx.fillText(row, x, y + count * line);
  };
  return {
    pickables: [face, board, computer, smallScreen],
    boardPoint: new THREE.Vector3(BOARD.x, 2.85, BOARD.z),
    computerPoint: computer
      .getWorldPosition(new THREE.Vector3())
      .add(new THREE.Vector3(0, 0.6, 0)),
    sync({ goal, tasks, artifacts, events }) {
      const completion = events.findLast((e) => e.type === "run.complete");
      const testResult = artifacts.findLast((a) => a.stage === "test")?.data
        ?.tests;
      const unresolved = ["review", "test"]
        .map((stage) => artifacts.findLast((a) => a.stage === stage))
        .filter((a) => a?.verdict === "revise");
      const ctx = white.context;
      ctx.fillStyle = "#e4e7d8";
      ctx.fillRect(0, 0, 1024, 540);
      ctx.fillStyle = "#657763";
      ctx.font = "bold 21px sans-serif";
      ctx.fillText("OUR GOAL / 共享白板", 34, 39);
      ctx.fillStyle = "#283d35";
      ctx.font = "bold 36px sans-serif";
      wrap(ctx, goal.title, 34, 89, 930, 43, 1);
      ctx.font = "23px sans-serif";
      wrap(ctx, goal.brief, 34, 136, 930, 30, 2);
      tasks.forEach((task, i) => {
        const x = 34 + (i % 3) * 325,
          y = 210 + Math.floor(i / 3) * 109;
        ctx.fillStyle = task.color;
        ctx.fillRect(x, y, 305, 89);
        ctx.fillStyle = "#1d3029";
        ctx.font = "bold 25px sans-serif";
        ctx.fillText(`${task.name} · ${task.role}`, x + 15, y + 30);
        ctx.font = "22px sans-serif";
        ctx.fillText(
          (task.task || STATUS_TEXT[task.status] || "待命").slice(0, 12),
          x + 15,
          y + 65,
        );
      });
      ctx.fillStyle = "#405349";
      ctx.font = "22px sans-serif";
      ctx.fillText(
        `${artifacts.length} 份产物 · ${goal.notes.length} 条讨论意见 · 点击查看与验收`,
        34,
        480,
      );
      ctx.font = "19px sans-serif";
      wrap(
        ctx,
        (completion?.delivery
          ? `Demo 已验证：${completion.delivery.tests.passedCount}/${completion.delivery.tests.total} · 点击电脑打开与下载`
          : unresolved.length
            ? `待修复：${unresolved.map((a) => a.summary).join("；")}`
            : null) ||
          goal.notes.at(-1)?.text ||
          goal.criteria[0] ||
          "先明确目标，再分工协作。",
        34,
        515,
        940,
        24,
        1,
      );
      white.texture.needsUpdate = true;
      const c = terminal.context;
      c.fillStyle = "#142329";
      c.fillRect(0, 0, 1024, 576);
      c.fillStyle = "#a8c995";
      c.font = "bold 31px monospace";
      c.fillText("TEAM COMPUTER / 协作电脑", 36, 52);
      c.font = "27px sans-serif";
      wrap(c, goal.title, 36, 101, 940, 34, 1);
      tasks.forEach((task, i) => {
        c.fillStyle = task.color;
        c.font = "26px sans-serif";
        c.fillText(
          `${task.name} / ${STATUS_TEXT[task.status] || "待命"} / ${task.artifacts.length}份产物`,
          36,
          160 + i * 45,
        );
      });
      c.fillStyle = "#d1ddbb";
      c.font = "22px sans-serif";
      const last = events.findLast((e) =>
        ["handoff", "tool", "revision", "run.complete"].includes(e.type),
      );
      wrap(
        c,
        last
          ? last.type === "handoff"
            ? `${last.from} → ${last.to}：${last.title}`
            : last.label ||
              last.message ||
              `Demo 已验证 · ${last.delivery?.tests.passedCount || artifacts.length} 项结果`
          : "等待第一份交接产物",
        36,
        471,
        940,
        30,
        2,
      );
      c.fillStyle = testResult && !testResult.passed ? "#ec9b8b" : "#d1ddbb";
      c.fillText(
        testResult
          ? `TEST ${testResult.passed ? "PASS" : "FAIL"} ${testResult.passedCount}/${testResult.total} · 点击查看日志与 Demo`
          : "点击屏幕查看共享产物",
        36,
        553,
      );
      terminal.texture.needsUpdate = true;
    },
    update(camera, firstPerson) {
      root.visible = firstPerson || camera.position.z > BOARD.z - 0.1;
    },
    dispose() {
      white.texture.dispose();
      terminal.texture.dispose();
      for (const group of [root, waterCorner])
        group.traverse((o) => {
          o.geometry?.dispose();
          o.material?.dispose();
        });
      scene.remove(root, waterCorner);
    },
  };
}
