import { TEAM, TEAM_BY_ID, STATUS_TEXT, DEFAULT_GOAL } from "../shared/team.js";
import { runCollaboration, DEMO_LINES } from "../shared/workflow.js";
import { Narrator } from "./narrator.js";
import { workLines } from "../shared/room-lines.js";

const $ = (id) => document.getElementById(id);
export class Collaboration {
  constructor({
    onAgent = () => {},
    onHandoff = () => {},
    onSpeaker = () => {},
    onSelect = () => {},
    onRunStart = () => {},
    stage = null,
  } = {}) {
    this.onAgent = onAgent;
    this.onHandoff = onHandoff;
    this.onSelect = onSelect;
    this.onRunStart = onRunStart;
    this.onSpeaker = onSpeaker;
    this.stage = stage;
    this.states = new Map(
      TEAM.map((member) => [member.id, { status: "idle", task: member.job }]),
    );
    this.artifacts = [];
    this.events = [];
    this.selected = "mori";
    this.controller = null;
    this.running = false;
    this.paused = false;
    this.mode = "demo";
    this.lastMode = "demo";
    this.lastGoal = DEFAULT_GOAL;
    this.apiReady = false;
    this.execution = "upstream";
    this.sandboxStatus = { available: false, reason: "正在检查本机执行环境。" };
    $("repository-execution-mode").onchange = (event) => { this.execution = event.target.value; this.renderMode(); };
    this.roomUnlocked = false;
    this.roomSoundEnabled = true;
    this.narrator = new Narrator({
      onChange: (event) => {
        this.presentSpeech(event);
      },
      onNotice: (message) => {
        this.notice(message);
        if (this.narrator.paused) {
          this.paused = true;
          this.stage?.pause(true);
          $("pause-team").textContent = "继续回放";
        }
      },
    });
    this.roomNarrator = new Narrator({
      audioId: "room-voice-audio",
      onChange: (event) => {
        const previous = this.roomSpeech;
        this.roomSpeech = event;
        if (event && !this.discussionBusy && !this.narrator.current)
          this.presentSpeech(event);
        else if (!event && this.currentSpeech === previous)
          this.presentSpeech(null);
        this.updateControls();
      },
      onNotice: (message) => {
        if (this.roomNarrator.paused) {
          this.roomUnlocked = false;
          this.roomNarrator.paused = false;
          this.roomNarrator.setEnabled(false);
          this.roomNarrator.skip();
          this.renderRoomSound();
        }
        $("room-sound").title = message;
        this.notice(message);
      },
    });
    this.roomNarrator.setEnabled(false);
    this.stage?.configureDialogue({
      speak: (event, signal) => {
        this.roomNarrator.setEnabled(
          this.roomUnlocked &&
            this.roomSoundEnabled &&
            $("voice-enabled").checked,
        );
        return this.roomNarrator.speak(event, signal);
      },
      cancel: () => this.roomNarrator.stop(),
      pause: (value) => {
        if (value) this.roomNarrator.pause();
        else this.roomNarrator.resume().catch(() => {});
      },
      workLines: (context) => workLines({ ...context, mode: this.mode }),
    });
    $("room-sound").addEventListener("click", async () => {
      if (
        this.roomUnlocked &&
        this.roomSoundEnabled &&
        $("voice-enabled").checked
      ) {
        this.roomSoundEnabled = false;
        this.roomNarrator.setEnabled(false);
        this.renderRoomSound();
      } else {
        this.roomSoundEnabled = true;
        $("voice-enabled").checked = true;
        this.narrator.setEnabled(true);
        await this.unlockRoomVoice();
      }
    });
    $("team-goal").value = DEFAULT_GOAL;
    $("start-team").addEventListener("click", () => this.start());
    $("pause-team").addEventListener("click", () => this.togglePause());
    $("stop-team").addEventListener("click", () => this.stop());
    $("voice-enabled").addEventListener("change", (e) => {
      this.narrator.setEnabled(e.target.checked);
      this.roomNarrator.setEnabled(
        e.target.checked && this.roomUnlocked && this.roomSoundEnabled,
      );
      this.renderRoomSound();
    });
    $("skip-speech").addEventListener("click", () =>
      (this.discussionBusy
        ? this.discussionNarrator
        : this.roomSpeech
          ? this.roomNarrator
          : this.narrator
      )?.skip(),
    );
    $("preview-voice").addEventListener("click", () => this.previewVoice());
    $("open-agent-output").addEventListener("click", () =>
      this.showActorArtifacts(),
    );
    $("export-team").addEventListener("click", () => this.export());
    $("close-artifact").addEventListener("click", () =>
      $("artifact-dialog").close(),
    );
    $("team-mode").addEventListener("change", (e) => {
      this.mode = e.target.value;
      this.renderMode();
    });
    this.renderMode();
    this.select("mori");
    this.updateControls();
    this.refreshConfig();
    document.addEventListener("visibilitychange", () => {
      if (
        document.hidden &&
        (this.running || this.roomSpeech) &&
        !this.paused &&
        !this.discussionBusy
      )
        this.togglePause();
    });
  }
  renderRoomSound() {
    const enabled =
      this.roomUnlocked && this.roomSoundEnabled && $("voice-enabled").checked;
    $("room-sound").textContent = enabled ? "房间语音：开" : "开启房间语音";
    $("room-sound").setAttribute("aria-pressed", String(enabled));
  }
  async unlockRoomVoice() {
    try {
      await this.roomNarrator.unlock();
      this.roomUnlocked = true;
      this.roomNarrator.setEnabled(
        this.roomSoundEnabled && $("voice-enabled").checked,
      );
    } catch {
      this.notice("房间语音暂时未能开启，互动字幕仍可观看。");
    }
    this.renderRoomSound();
  }
  stopRoomSpeech({ preserveWork = false } = {}) {
    this.stage?.cancelSocial();
    if (!preserveWork || !["work", "handoff"].includes(this.roomSpeech?.kind))
      this.roomNarrator.stop();
  }
  getSpeechLevel() {
    return (this.roomSpeech ? this.roomNarrator : this.narrator).getLevel();
  }
  notice(message) {
    $("team-notice").textContent = message;
    this.stage?.notice(message);
  }
  async refreshConfig() {
    try {
      const response = await fetch(new URL("api/status", document.baseURI));
      if (!response.ok) throw new Error();
      const config = await response.json();
      this.apiReady = config.agents.configured;
      this.sandboxStatus = config.repository?.sandbox || { available: false, reason: "本地服务未提供原仓库执行器。" };
      $("live-option").disabled = !this.apiReady;
      $("repository-option").disabled = !config.repository?.enabled;
      $("voice-connection").textContent = config.speech.configured
        ? "MiniMax 已连接 · 六种音色"
        : "MiniMax 预生成语音";
    } catch {
      $("voice-connection").textContent = "MiniMax 预生成语音";
      $("live-option").disabled = true;
      $("repository-option").disabled = true;
    }
    this.syncState();
  }
  renderMode() {
    const live = this.mode !== "demo";
    $("repository-url-field").hidden = this.mode !== "repository";
    $("repository-execution-field").hidden = this.mode !== "repository";
    $("repository-execution-mode").value = this.execution;
    $("mode-description").textContent =
      this.mode === "repository"
        ? this.execution === "upstream"
          ? this.sandboxStatus.available ? `原仓库执行 · ${this.sandboxStatus.provider}：克隆、安装、修改、原有构建测试、启动 Demo。` : this.sandboxStatus.reason
          : "读取固定版本源码，独立实现离线 Demo，执行隔离功能测试后交付。"
        : live
          ? "六位角色调用真实模型，依次读取并提交产物。"
          : "预设流程演示：展示并行检查与返工，使用 MiniMax 生成语音。";
    $("run-kind").textContent =
      this.mode === "repository"
        ? "真实 GitHub 任务"
        : live
          ? "真实 Agent 协作"
          : "预设协作演示";
    this.select(this.selected);
  }
  updateControls() {
    $("start-team").disabled = this.running;
    $("mobile-start").disabled = this.running;
    $("mobile-start").textContent = this.running ? "协作进行中" : "开始协作";
    $("pause-team").disabled = !this.running;
    $("stop-team").disabled = !this.running;
    $("team-mode").disabled = this.running || this.discussionBusy;
    $("stage-pause").disabled =
      !this.running && !this.discussionBusy && !this.roomSpeech && !this.paused;
    $("stage-stop").disabled =
      !this.running && !this.discussionBusy && !this.roomSpeech && !this.paused;
    $("team-goal").disabled = this.running || this.discussionBusy;
    $("repository-url").disabled = this.running || this.discussionBusy;
    $("repository-execution-mode").disabled = this.running || this.discussionBusy;
    $("open-repository").disabled = this.running || this.discussionBusy;
    $("preview-voice").disabled = this.running || this.discussionBusy;
    $("goal-select").disabled = this.running || this.discussionBusy;
    $("pause-team").disabled = !this.running || this.discussionBusy;
    $("start-team").disabled = this.running || this.discussionBusy;
    $("mobile-start").disabled = this.running || this.discussionBusy;
    $("export-team").disabled = !this.artifacts.length;
    this.syncState();
  }
  syncState() {
    $("team-workspace").dataset.state = JSON.stringify({
      mode: this.mode,
      running: this.running,
      paused: this.paused,
      eventCount: this.events.length,
      artifactCount: this.artifacts.length,
      statuses: Object.fromEntries(this.states),
      speaker: this.currentSpeech?.actor || null,
    });
    this.onUpdate?.();
  }
  select(actor) {
    this.selected = actor;
    const member = TEAM_BY_ID[actor];
    if (!member) return;
    const state = this.states.get(actor);
    $("agent-role").textContent = member.role;
    $("talk-agent").textContent = `和${member.name}对话 ↗`;
    $("agent-instance").textContent =
      `${actor} / ${this.mode === "repository" && this.execution === "upstream" && ["momo", "sleepy"].includes(actor) ? "实际命令与交付执行器" : this.mode !== "demo" ? "MiniMax Agent" : "演示角色"}`;
    $("agent-state").textContent =
      this.currentSpeech?.actor === actor
        ? "发言中"
        : this.currentSpeech?.to === actor
          ? "倾听中"
          : STATUS_TEXT[state.status];
    $("agent-state").dataset.status = state.status;
    $("resident-activity").textContent = state.task;
    $("resident-description").textContent =
      this.mode === "repository"
        ? this.execution === "upstream" ? {
            mori: "拆解原项目目标与验收要求",
            amber: "克隆固定版本，阅读原仓库源码与运行方式",
            indigo: "修改原项目文件，修复真实构建及测试问题",
            luna: "审阅真实代码差异和目标实现情况",
            momo: "运行原有 build/test，返回真实退出码与日志",
            sleepy: "核对通过的版本与运行地址，归档源码和命令证据",
          }[actor] : {
            mori: "拆解 Demo 目标与验收要求",
            amber: "阅读固定版本源码并保留研究证据",
            indigo: "编写真实 Demo 文件，修复审阅与测试问题",
            luna: "检查实际代码与上游语义，提出返工意见",
            momo: "独立编写功能断言，在隔离环境真实运行测试",
            sleepy: "核对已通过的版本，整理源码包与运行说明",
          }[actor]
        : member.job;
    const count = this.artifacts.filter((item) => item.actor === actor).length;
    $("open-agent-output").textContent = count
      ? `查看 ${count} 份产物 ↗`
      : "查看角色任务 ↗";
  }
  reset() {
    this.stage?.stop("准备开始 · 人物会走到白板前分工");
    this.narrator.stop();
    this.events = [];
    this.artifacts = [];
    $("artifact-count").textContent = "0";
    $("event-log").replaceChildren();
    $("artifact-list").replaceChildren();
    $("team-progress").textContent = "等待开始";
    $("team-notice").textContent = "";
    TEAM.forEach((member) => {
      const state = { status: "idle", task: member.job };
      this.states.set(member.id, state);
      this.onAgent(member.id, state);
    });
    this.stage?.idle();
    this.select(this.selected);
  }
  async start() {
    if (this.running || this.discussionBusy) return;
    const goal = $("team-goal").value.trim();
    if (this.mode === "repository") {
      if (this.execution === "upstream" && !this.sandboxStatus.available) {
        await this.refreshConfig();
        if (!this.sandboxStatus.available) return this.notice(this.sandboxStatus.reason);
      }
      this.repositoryURL = $("repository-url").value.trim();
      try {
        const url = new URL(this.repositoryURL);
        if (
          url.protocol !== "https:" ||
          url.hostname !== "github.com" ||
          !/^\/[\w-]+\/[\w.-]+\/?$/.test(url.pathname) ||
          url.search ||
          url.hash ||
          url.username ||
          url.password ||
          url.port
        )
          throw new Error();
      } catch {
        this.notice("请填写完整的公开 GitHub 仓库首页地址。");
        return;
      }
    }
    if (!goal || goal.length > 400) {
      this.notice("请填写 1 至 400 字的协作目标。");
      return;
    }
    try {
      this.goalContext = this.beforeStart?.(goal) || {};
    } catch (error) {
      this.notice(error.message);
      return;
    }
    this.reset();
    this.onRunStart();
    this.controller = new AbortController();
    this.lastMode = this.mode;
    this.lastGoal = goal;
    this.running = true;
    this.paused = false;
    $("pause-team").textContent = "暂停回放";
    this.updateControls();
    const signal = this.controller.signal;
    this.playback = Promise.resolve();
    const enqueue = (event) => {
      this.playback = this.playback.then(() => this.replay(event, signal));
      // The workflow emits synchronously; its next narration drains this queue.
      this.playback.catch(() => {});
    };
    try {
      if (this.roomSoundEnabled && $("voice-enabled").checked)
        await this.unlockRoomVoice();
      await this.narrator.unlock();
      if (this.mode === "demo")
        await runCollaboration({
          goal,
          context: this.goalContext,
          signal: this.controller.signal,
          pace: 650,
          emit: enqueue,
          narrate: async (event) => {
            await this.playback;
            await this.speakInScene(event, signal);
          },
        });
      else await this.runLive(goal, this.controller.signal);
      await this.playback;
    } catch (error) {
      if (this.controller.signal.aborted)
        this.notice("协作与播报已停止，已生成的产物仍可查看。");
      else {
        this.controller.abort();
        this.stage?.stop();
        if (this.events.at(-1)?.type !== "run.error")
          this.apply({
            type: "run.error",
            message: error.message,
            time: Date.now(),
          });
        this.notice(error.message);
        $("team-progress").textContent = "执行中断";
      }
    } finally {
      this.running = false;
      this.paused = false;
      this.narrator.stop();
      $("pause-team").textContent = "暂停回放";
      this.updateControls();
      this.select(this.selected);
    }
  }
  async replay(event, signal) {
    await this.narrator.waitResumed(signal);
    signal.throwIfAborted();
    await this.stage?.play(event, signal);
    signal.throwIfAborted();
    this.apply(event);
  }
  async speakInScene(event, signal) {
    await this.narrator.waitResumed(signal);
    await this.stage?.prepareSpeech(event, signal);
    await this.narrator.speak(event, signal);
    signal.throwIfAborted();
    this.stage?.finishSpeech(event);
  }
  async runLive(goal, signal) {
    const repository = this.mode === "repository";
    const response = await fetch(
      new URL(repository ? "api/repository/run" : "api/run", document.baseURI),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal,
          mode: this.mode,
          context: this.goalContext,
          ...(repository ? { url: this.repositoryURL, execution: this.execution, sceneSync: true } : {}),
        }),
        signal,
      },
    );
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "真实协作未能启动。");
    }
    const reader = response.body.getReader(),
      decoder = new TextDecoder();
    let buffer = "",
      complete = false;
    const process = async (line) => {
      if (!line.trim()) return;
      await this.narrator.waitResumed(signal);
      signal.throwIfAborted();
      const event = JSON.parse(line);
      await this.replay(event, signal);
      if (event.ackId) {
        const ack = await fetch(
          new URL("api/repository/ack", document.baseURI),
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ackId: event.ackId }),
            signal,
          },
        );
        if (!ack.ok)
          throw new Error("人物到达工位后的阶段确认失败，请重新开始任务。");
      }
      if (event.type === "speech") await this.speakInScene(event, signal);
      if (event.type === "run.error") throw new Error(event.message);
      if (event.type === "run.complete") complete = true;
    };
    try {
      while (true) {
        const { value, done } = await reader.read();
        buffer += decoder.decode(value, { stream: !done });
        let split;
        while ((split = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, split);
          buffer = buffer.slice(split + 1);
          await process(line);
        }
        if (done) {
          await process(buffer);
          break;
        }
      }
      if (!complete) throw new Error("协作连接提前结束，已保留收到的产物。");
    } finally {
      reader.releaseLock();
    }
  }
  apply(event) {
    this.events.push(event);
    if (event.type === "run.start") {
      $("team-progress").textContent = "正在拆分目标";
      this.addLog("任务开始", event.goal);
    }
    if (event.type === "agent.state") {
      const state = { status: event.status, task: event.task };
      this.states.set(event.actor, state);
      this.onAgent(event.actor, state);
      this.select(this.selected);
      if (["working", "reviewing", "testing"].includes(event.status))
        $("team-progress").textContent =
          `${TEAM_BY_ID[event.actor].name} · ${event.task}`;
    }
    if (event.type === "tool")
      this.addLog(
        `${TEAM_BY_ID[event.actor].name} · ${TEAM_BY_ID[event.actor].role}`,
        event.label,
      );
    if (event.type === "artifact") {
      this.artifacts.push(event.artifact);
      const button = document.createElement("button");
      button.className = "artifact-item";
      button.textContent = `▤ ${event.artifact.title}`;
      button.addEventListener("click", () => this.showArtifact(event.artifact));
      $("artifact-list").prepend(button);
      $("artifact-count").textContent = String(this.artifacts.length);
      this.updateControls();
      this.select(this.selected);
    }
    if (event.type === "handoff") {
      this.onHandoff(event);
      this.addLog(
        `${TEAM_BY_ID[event.from].name} → ${TEAM_BY_ID[event.to].name}`,
        `交接：${event.title}`,
      );
    }
    if (event.type === "speech")
      this.addLog(`${TEAM_BY_ID[event.actor].name}发言`, event.text);
    if (event.type === "revision") {
      $("team-progress").textContent = "合并反馈，返回开发员";
      this.addLog("需要返工", event.message);
    }
    if (event.type === "run.complete") {
      $("team-progress").textContent =
        `协作完成 · ${event.artifactCount} 份产物`;
      this.addLog("本轮交付完成", "产物已归档，可查看或导出。");
    }
    if (event.type === "run.error") {
      this.notice(event.message);
      for (const [actor, state] of this.states)
        if (
          ["working", "reviewing", "testing", "queued"].includes(state.status)
        ) {
          state.status = "cancelled";
          state.task = "本轮已中断，等待重新开始";
          this.onAgent(actor, state);
        }
      this.select(this.selected);
    }
    this.syncState();
  }
  addLog(title, text) {
    const item = document.createElement("div");
    item.className = "event-item";
    const heading = document.createElement("strong");
    heading.textContent = title;
    const body = document.createElement("p");
    body.textContent = text;
    item.append(heading, body);
    $("event-log").prepend(item);
    while ($("event-log").children.length > 60)
      $("event-log").lastChild.remove();
  }
  renderSpeaker(event) {
    document.body.classList.toggle("speaking", Boolean(event));
    $("speech-bar").hidden = !event;
    $("skip-speech").disabled = !event;
    if (event) {
      const member = TEAM_BY_ID[event.actor];
      $("speaker-name").textContent = event.to
        ? `${member.name} → ${TEAM_BY_ID[event.to].name}`
        : `${member.name} · ${member.role}`;
      $("speech-text").textContent = event.text;
      $("speech-origin").textContent = this.narrator.enabled
        ? event.clip
          ? "MiniMax · 预生成语音"
          : "MiniMax · 实时合成"
        : "字幕回放";
      if (["room", "work", "handoff"].includes(event.kind))
        $("speech-origin").textContent =
          `${this.roomUnlocked && this.roomSoundEnabled && $("voice-enabled").checked ? "MiniMax" : "字幕"} · ${event.kind === "room" ? "房间互动短句" : event.collection === "room" ? "任务交接短句" : "交接产物摘要"}`;
      if ($("follow-speaker").checked) this.onSelect(event.actor);
    }
    $("team-workspace").dataset.speaker = event?.actor || "";
    this.syncState();
  }
  presentSpeech(event) {
    this.currentSpeech = event;
    this.select(this.selected);
    this.onSpeaker(event?.actor || null, event?.to || null, event);
    this.renderSpeaker(event);
  }
  async togglePause() {
    if (!this.running) {
      if (!this.roomSpeech && !this.paused) return;
      this.paused = !this.paused;
      this.stage?.pause(this.paused);
      this.updateControls();
      return;
    }
    this.paused = !this.paused;
    if (this.paused) this.narrator.pause();
    else {
      try {
        await this.stage?.resume(this.controller.signal);
      } catch (error) {
        if (!this.controller.signal.aborted) this.notice(error.message);
        return;
      }
      this.presentSpeech(this.roomSpeech || this.narrator.current);
      await this.narrator.resume();
    }
    this.stage?.pause(this.paused);
    $("pause-team").textContent = this.paused ? "继续回放" : "暂停回放";
    this.syncState();
  }
  stop() {
    this.controller?.abort();
    this.cancelDiscussion?.();
    this.stage?.stop();
    this.narrator.stop();
    for (const [id, state] of this.states)
      if (
        ["working", "reviewing", "testing", "queued"].includes(state.status)
      ) {
        state.status = "cancelled";
        this.onAgent(id, state);
      }
    this.select(this.selected);
    $("team-progress").textContent = "已停止 · 产物保留";
    this.syncState();
  }
  async previewVoice() {
    if (this.running) return;
    this.stopRoomSpeech();
    const clip = {
      mori: "plan",
      amber: "research",
      indigo: "draft",
      luna: "review_pass",
      momo: "test_pass",
      sleepy: "record",
    }[this.selected];
    $("preview-voice").disabled = true;
    try {
      await this.narrator.unlock();
      await this.narrator.speak(
        { actor: this.selected, text: DEMO_LINES[clip].text, clip },
        new AbortController().signal,
      );
    } finally {
      $("preview-voice").disabled = this.running;
    }
  }
  showActorArtifacts() {
    const outputs = this.artifacts.filter(
      (item) => item.actor === this.selected,
    );
    if (outputs.length) this.showArtifact(outputs.at(-1));
    else {
      const member = TEAM_BY_ID[this.selected];
      this.showArtifact({
        title: `${member.name} · ${member.role}`,
        content: `职责：${member.job}\n\n当前任务：${this.states.get(this.selected).task}\n\n状态：${STATUS_TEXT[this.states.get(this.selected).status]}\n\n暂无产物。`,
        inputIds: [],
      });
    }
  }
  showArtifact(artifact) {
    $("artifact-title").textContent = artifact.title;
    $("artifact-meta").textContent = artifact.actor
      ? `${TEAM_BY_ID[artifact.actor].name} · 输入 ${artifact.inputIds.length} 份产物`
      : "角色任务";
    $("artifact-content").textContent = artifact.content;
    $("artifact-dialog").showModal();
  }
  export() {
    const body = {
      goal: this.lastGoal,
      mode: this.lastMode,
      exportedAt: new Date().toISOString(),
      reportId:
        this.events.findLast((event) => event.type === "run.complete")
          ?.reportId || null,
      artifacts: this.artifacts,
      events: this.events,
    };
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(body, null, 2)], { type: "application/json" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "agent-room-collaboration.json";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  dispose() {
    this.stop();
    this.narrator.dispose();
    this.roomNarrator.dispose();
  }
}
