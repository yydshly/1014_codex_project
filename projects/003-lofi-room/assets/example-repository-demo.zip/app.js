// mitt 事件总线实验室 · UI 控制
(function () {
  'use strict';
  var API = globalThis.DemoAPI;

  function $(id) { return document.getElementById(id); }
  function refreshSubs() {
    var sel = $('subList');
    sel.innerHTML = '';
    API.listSubs().forEach(function (s) {
      var opt = document.createElement('option');
      opt.textContent = s;
      opt.value = s;
      sel.appendChild(opt);
    });
  }
  function parseJSON(s) {
    if (s === undefined || s === null || s === '') return undefined;
    try { return JSON.parse(s); } catch (e) { return s; }
  }

  API.bindLog($('log'));

  $('btnPreset').onclick = function () {
    API.on('foo', 'h-foo');
    API.on('*', 'h-star');
    refreshSubs();
  };
  $('btnOn').onclick = function () {
    var t = $('onType').value.trim() || 'foo';
    var n = $('onName').value.trim() || ('h-' + t);
    API.on(t, n);
    refreshSubs();
  };
  $('btnOff').onclick = function () {
    var sel = $('subList');
    if (!sel.value) return;
    var parts = sel.value.split(' / ');
    API.off(parts[0], parts[1]);
    refreshSubs();
  };
  $('btnOffAll').onclick = function () {
    var sel = $('subList');
    if (!sel.value) return;
    var parts = sel.value.split(' / ');
    API.offAll(parts[0]);
    refreshSubs();
  };
  $('btnEmit').onclick = function () {
    var t = $('emitType').value.trim() || 'foo';
    var d = parseJSON($('emitData').value);
    API.emit(t, d);
  };
  $('btnEmitStar').onclick = function () {
    var d = parseJSON($('emitData').value);
    API.emit('*', d);
  };
  $('btnClearLog').onclick = function () {
    API.clearLog();
  };
  $('btnReset').onclick = function () {
    API.reset();
    API.clearLog();
    refreshSubs();
  };

  refreshSubs();
})();
