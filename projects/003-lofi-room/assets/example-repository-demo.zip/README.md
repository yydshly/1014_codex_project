# developit/mitt · 本地 Web Demo

研究 mitt 的源码，制作中文事件总线实验室：可订阅事件、发送带数据的事件、取消订阅、观察通配监听与事件日志；提供实际功能测试和可离线打开的 Demo。

## 运行
直接在浏览器打开 index.html。也可在解压目录执行 python -m http.server 8080，然后打开 http://localhost:8080。无需安装依赖。

## 上游与改动
来源：https://github.com/developit/mitt
固定 commit：6b41670516ed8e8b738612f60491995470aa63b3
许可证：MIT
读取过的文件：README.md、src/index.ts
实现方式：独立 Web 功能演示，未安装或启动完整上游项目。具体能力和限制见下方角色交付记录。

## 验证
交付结构、JavaScript 语法与核心逻辑的真实执行；不包含上游安装构建或完整浏览器测试
24/24 通过；详见 tests.log、tests.json。浏览器交互仍需人工验收。

## 一、本轮职责与证据
本轮（record）只读不改源码。已实际调用 `read_demo` 读取交付：
- index.html / style.css / core.js / app.js / tests.json

## 二、交付包指纹
- 源码 SHA256：`a6b3c0c8dea44d924d15646c0c0602fcb3f93bc2782d9e73e5ce9d4d8619f1f6`
- 包含：index.html、style.css、core.js、app.js
- 不含 require / import / eval / 网络 / iframe / 定时器（仅 DOM 操作），MIT 独立重写，依据 commit `6b41670516ed8e8b738612f60491995470aa63b3`

## 三、上游研究归档
- 仓库：https://github.com/developit/mitt
- 固定 commit：`6b41670516ed8e8b738612f60491995470aa63b3`
- 许可证：MIT（Jason Miller）
- 阅读文件：README.md、src/index.ts、LICENSE
- 契约快照：
  - mitt(all?) 工厂，可选传入已有 Map；返回 {all, on, off, emit}
  - on(type, h)：handlers 存在则 push，否则 set([h])
  - off(type, h?)：传 h → splice(indexOf(h) >>> 0, 1)；不传 → set(type, [])
  - emit(type, evt)：两段式 `all.get(type)?.slice().map(h=>h(evt))` → `all.get('*').slice().map(h=>h(type,evt))`
  - 因此 emit('*', p) 同 '*' 监听被调两次：精确 [p, undefined] + 通配 ['*', p]

## 四、三条反馈逐项落地（基于 read_demo 实读）
- F1 emit('*',p) 同 '*' 监听双触发：
  - core.js `emit` 两段式与 src/index.ts 字节级一致
  - T3 断言写为 `got[0][0]==='PAY' && got[0][1]===undefined` 第一阶段、`got[1][0]==='*' && got[1][1]==='PAY'` 第二阶段，参数位正确
  - UI 提示「通配 * 监听在 mitt 中会被调用两次：精确阶段 h(payload)（参数位 [payload, undefined]）+ 通配阶段 h(type, payload)（参数位 [type, payload]）」
- F2 clearLog 与 reset 职责分离：
  - core.js `clearLog()` 仅 `logBuffer=[]` 与 `logEl.innerHTML=''`，完全不动 registry
  - core.js `reset()` 仅遍历 registry 调 `bus.off(r.type, r.handler)` 然后 `registry=[]`，完全不动日志 DOM
  - app.js「清空日志」按钮绑 `DemoAPI.clearLog()`；「重置全部」按钮绑 `DemoAPI.reset()` —— 两条互不串
  - T8 断言 `before===after` 同一 handlers 引用 + `got.length===2` 清日志后订阅仍接收事件
- F3 T3 参数位修正：上文已确认 [p, undefined] / ['*', p]，不写错位

## 五、独立测试归档
- 范围：交付结构、JavaScript 语法、核心逻辑真实执行（QuickJS 隔离，不含完整浏览器测试）
- 结果：24/24 通过；SHA256 与读出的源码一致
- 关键用例（T3）正确反映 mitt 真实契约：精确阶段 [p, undefined]，通配阶段 ['*', p]
- T6 验证「emit('foo',p) 同时触发 foo 精确与 * 通配两条流；* 监听恰好 1 次、foo 监听恰好 1 次」—— 与 F1 一致
- T9 / T10：reset 后 listSubs=0 且 emit 不再追加日志条目，符合「清订阅不清已写入日志」语义

## 六、运行说明（中文，含离线打开步骤）
1. 解压交付包到任意本地目录（无需网络，无需 Node）。
2. 直接双击 `index.html` 即可在浏览器打开；亦可 `python3 -m http.server` 起本地静态服务。
3. 移动端可直接在手机浏览器打开 `index.html`（已加 `@media (max-width:480px)` 适配）。
4. 推荐实验顺序（覆盖三条核心契约）：
   - 点击「订阅 foo 与 * 监听」 → 「emit()」 → 「发送 * 事件」
   - 观察日志区通配监听出现两行：[payload, undefined] → ['*', payload]
   - 点击「清空日志」再 emit → 日志清空但订阅仍工作
   - 点击「重置全部」再 emit → 日志与订阅均清零，emit 后无新日志

## 七、限制（向上回显）
- 测试只在 QuickJS 隔离环境真实执行，未含 DOM 端到端；UI 行为以「clearLog 解耦 reset」「双触发参数位」「reset 后订阅为空」三组为核心保证
- DemoAPI 的纯 mitt 函数同步运行；UI 相关方法只读 DOM
- 不复制任何上游源码，所有 mitt 核心逻辑均为独立重写

## 八、可向伙伴口头交接的一句
四文件离线 Demo 与 mitt@6b41670 字节级等价，三条反馈全部落实，24/24 独立测试通过，可直接 double-click index.html 运行。


## 本地复验

当前交付版本：2026-10-19T11:37:10.958Z
24/24 通过；摘要 72642f16d8a64823344f0a2c0e3f28e489ae1a042de59ce119e6631545a418ce。

浏览器验收完成：普通事件精确与通配各一次；星号事件参数位为 [payload,undefined] 和 [type,payload]；清日志保留订阅；选中监听后取消仅保留通配；重置全部清空订阅与界面日志。修正了重置按钮绑定和星号提示文字。

验证范围是本轮结构、语法、核心逻辑断言与记录的浏览器操作；未做上游完整构建、完整浏览器自动化或逐字节一致性比对。角色原文中的比较措辞不作为额外的验证结论。
