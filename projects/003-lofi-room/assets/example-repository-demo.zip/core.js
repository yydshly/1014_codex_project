// mitt 事件总线实验室 · 核心逻辑
// 依据 mitt@6b41670516ed8e8b738612f60491995470aa63b3 (MIT) 的 src/index.ts 独立重写
// 契约：on/off/emit/all 行为与上游字节级等价；emit('*',p) 同 '*' 监听被调两次
(function () {
  'use strict';

  // 工厂：与上游 mitt() 一致，可选传入已有 Map
  function mitt(all) {
    all = all || new Map();
    return {
      all: all,
      on: function (type, handler) {
        var handlers = all.get(type);
        if (handlers) {
          handlers.push(handler);
        } else {
          all.set(type, [handler]);
        }
      },
      off: function (type, handler) {
        var handlers = all.get(type);
        if (handlers) {
          if (handler) {
            handlers.splice(handlers.indexOf(handler) >>> 0, 1);
          } else {
            all.set(type, []);
          }
        }
      },
      // 两段式：先精确 h(evt)，再通配 h(type, evt)
      emit: function (type, evt) {
        var handlers = all.get(type);
        if (handlers) {
          handlers.slice().map(function (h) { h(evt); });
        }
        handlers = all.get('*');
        if (handlers) {
          handlers.slice().map(function (h) { h(type, evt); });
        }
      }
    };
  }

  // 实验用共享 emitter 与订阅登记表（供 UI 与测试使用）
  var bus = mitt();
  // 每个处理器附带一个名字，便于在 UI 中识别与取消订阅
  var registry = []; // [{type, name, handler}]
  var eventSeq = 0;

  function findHandler(type, name) {
    for (var i = 0; i < registry.length; i++) {
      if (registry[i].type === type && registry[i].name === name) return registry[i];
    }
    return null;
  }

  // UI 调用：订阅；handler 内部把"被调用的事实"写入日志缓冲
  function on(type, name) {
    var handler = function (a, b) {
      // 关键：参数位 [a, b] 必须如实记录，便于观察 mitt 的双触发契约
      eventSeq++;
      logBuffer.push({
        seq: eventSeq,
        type: type,
        name: name,
        args: [a, b],
        ts: Date.now()
      });
      renderLog();
    };
    bus.on(type, handler);
    registry.push({ type: type, name: name, handler: handler });
    return handler;
  }

  // UI 调用：按 name 取消订阅
  function off(type, name) {
    var rec = findHandler(type, name);
    if (!rec) return false;
    bus.off(type, rec.handler);
    registry = registry.filter(function (r) { return r !== rec; });
    return true;
  }

  function offAll(type) {
    bus.off(type);
    registry = registry.filter(function (r) { return r.type !== type; });
  }

  function emit(type, evt) {
    bus.emit(type, evt);
  }

  function reset() {
    // 仅清订阅与注册表，不动日志 DOM
    registry.forEach(function (r) { bus.off(r.type, r.handler); });
    registry = [];
  }

  // 日志缓冲与渲染（与订阅解耦，供 clearLog 单独控制）
  var logBuffer = [];
  var logEl = null;

  function bindLog(el) { logEl = el; renderLog(); }

  function renderLog() {
    if (!logEl) return;
    logEl.innerHTML = '';
    logBuffer.forEach(function (e) {
      var li = document.createElement('li');
      if (e.type === '*') li.className = 'wild';
      var a = e.args[0], b = e.args[1];
      var sig = (b === undefined) ? JSON.stringify(a) : (JSON.stringify(a) + ', ' + JSON.stringify(b));
      li.textContent = '#' + e.seq + ' [' + e.name + '] <- ' + e.type + '(' + sig + ')';
      logEl.appendChild(li);
    });
    logEl.scrollTop = logEl.scrollHeight;
  }

  function clearLog() {
    // 只清日志 DOM 与缓冲，不动订阅
    logBuffer = [];
    if (logEl) logEl.innerHTML = '';
  }

  function getLog() { return logBuffer.slice(); }

  function listSubs() {
    return registry.map(function (r) { return r.type + ' / ' + r.name; });
  }

  globalThis.DemoAPI = {
    mitt: mitt,
    on: on,
    off: off,
    offAll: offAll,
    emit: emit,
    reset: reset,
    clearLog: clearLog,
    bindLog: bindLog,
    getLog: getLog,
    listSubs: listSubs
  };
})();
