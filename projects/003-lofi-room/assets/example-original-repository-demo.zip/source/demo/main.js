// 事件总线实验室 —— 仅消费 mitt 公开接口，不触碰 mitt 源码。
// 通过相对路径加载原项目 microbundle 真实构建产物 dist/mitt.mjs。
import mitt from '../dist/mitt.mjs';

// ---------- 全局状态 ----------
const state = {
	// 已订阅的 handler 列表：{ type -> [handler] }，用于精准 off。
	handlers: new Map(),
	wildcardHandler: null,
	logCounter: 0
};

const bus = mitt();

// ---------- DOM ----------
const $ = (id) => document.getElementById(id);

const els = {
	status: $('mitt-status'),
	handlerCount: $('handlers-count'),
	onType: $('on-type'),
	onBtn: $('on-btn'),
	onList: $('on-list'),
	offAllBtn: $('off-all-btn'),
	offSummary: $('off-summary'),
	emitType: $('emit-type'),
	emitPayload: $('emit-payload'),
	emitBtn: $('emit-btn'),
	wildcardToggle: $('wildcard-toggle'),
	clearLogBtn: $('clear-log-btn'),
	sampleBtn: $('sample-btn'),
	log: $('log')
};

// ---------- 日志渲染 ----------
function appendLog(kind, message) {
	state.logCounter += 1;
	const li = document.createElement('li');
	li.className = `log-item log-${kind}`;
	li.innerHTML = `<span class="seq">#${state.logCounter}</span><span class="time">${new Date().toLocaleTimeString()}</span><span class="msg"></span>`;
	li.querySelector('.msg').textContent = message;
	els.log.insertBefore(li, els.log.firstChild);
	// 日志最多保留 100 条，避免 DOM 内存膨胀。
	while (els.log.children.length > 100) {
		els.log.removeChild(els.log.lastChild);
	}
}

function renderHandlers() {
	const total = Array.from(state.handlers.values()).reduce((sum, arr) => sum + arr.length, 0);
	els.handlerCount.textContent = `订阅总数：${total}`;

	const entries = [];
	for (const [type, handlers] of state.handlers) {
		if (handlers.length === 0) continue;
		entries.push({ type, handlers });
	}
	if (entries.length === 0) {
		els.onList.innerHTML = '';
		els.offSummary.textContent = '暂无订阅';
		return;
	}

	els.onList.innerHTML = '';
	for (const { type, handlers } of entries) {
		const li = document.createElement('li');
		li.className = 'handler-row';
		const title = document.createElement('span');
		title.innerHTML = `<code></code> <small>×</small><b></b>`;
		title.querySelector('code').textContent = type;
		title.querySelector('small').textContent = ` ${handlers.length} `;
		const removeBtn = document.createElement('button');
		removeBtn.className = 'danger';
		removeBtn.textContent = '取消';
		removeBtn.addEventListener('click', () => removeHandler(type, 0));
		li.appendChild(title);
		li.appendChild(removeBtn);
		els.onList.appendChild(li);
	}

	els.offSummary.innerHTML = '';
	for (const { type, handlers } of entries) {
		const span = document.createElement('span');
		span.className = 'pill';
		span.innerHTML = `<code></code> ×<b></b>`;
		span.querySelector('code').textContent = type;
		span.querySelector('b').textContent = handlers.length;
		els.offSummary.appendChild(span);
	}
}

// ---------- 订阅 ----------
function addHandler(type) {
	const trimmed = (type || '').trim();
	if (!trimmed) {
		appendLog('warn', '订阅失败：事件名不能为空');
		return;
	}
	const handler = (evt) => {
		appendLog('on', `[on] ${trimmed} 收到 → ${formatPayload(evt)}`);
	};
	bus.on(trimmed, handler);
	const arr = state.handlers.get(trimmed) || [];
	arr.push(handler);
	state.handlers.set(trimmed, arr);
	appendLog('info', `已订阅 "${trimmed}"（当前 ${arr.length} 个 handler）`);
	renderHandlers();
}

function removeHandler(type, index) {
	const arr = state.handlers.get(type);
	if (!arr || arr.length === 0) return;
	const handler = arr[index];
	if (!handler) return;
	bus.off(type, handler);
	arr.splice(index, 1);
	if (arr.length === 0) state.handlers.delete(type);
	appendLog('info', `已取消订阅 "${type}"（剩余 ${arr.length} 个）`);
	renderHandlers();
}

function clearAllHandlers() {
	for (const [type, handlers] of state.handlers) {
		handlers.slice().forEach((h) => bus.off(type, h));
	}
	state.handlers.clear();
	// 真正调用 mitt 的 all.clear() —— 用户明确要求清空全部订阅时才执行。
	bus.all.clear();
	state.wildcardHandler = null;
	els.wildcardToggle.checked = false;
	appendLog('warn', '已清空全部订阅，并调用 bus.all.clear()');
	renderHandlers();
}

// ---------- 通配 ----------
function setWildcard(enabled) {
	if (enabled && !state.wildcardHandler) {
		const handler = (type, evt) => {
			appendLog('wild', `[*] 收到事件 "${String(type)}" → ${formatPayload(evt)}`);
		};
		state.wildcardHandler = handler;
		bus.on('*', handler);
		appendLog('info', '通配监听已开启');
	} else if (!enabled && state.wildcardHandler) {
		bus.off('*', state.wildcardHandler);
		state.wildcardHandler = null;
		appendLog('info', '通配监听已关闭');
	}
}

// ---------- 发送 ----------
function emitEvent() {
	const type = els.emitType.value.trim();
	if (!type) {
		appendLog('warn', '发送失败：事件名不能为空');
		return;
	}
	const raw = els.emitPayload.value;
	let evt;
	if (raw === '') {
		evt = undefined;
	} else {
		try {
			evt = JSON.parse(raw);
		} catch (err) {
			evt = raw; // JSON 解析失败则按字符串原样传递
			appendLog('warn', `负载非合法 JSON，已按字符串透传：${raw}`);
		}
	}
	appendLog('emit', `emit("${type}"，${formatPayload(evt)})`);
	bus.emit(type, evt);
}

// ---------- 辅助 ----------
function formatPayload(value) {
	if (value === undefined) return '(无负载)';
	try {
		return JSON.stringify(value);
	} catch (err) {
		return String(value);
	}
}

// ---------- 一键示例 ----------
function runSample() {
	addHandler('login');
	addHandler('logout');
	addHandler('user:update');
	if (!state.wildcardHandler) {
		els.wildcardToggle.checked = true;
		setWildcard(true);
	}
	bus.emit('login', { user: '张三', at: Date.now() });
	bus.emit('user:update', { id: 1, name: '张三' });
	bus.emit('logout', '已退出');
	appendLog('info', '一键示例完成：订阅 login/logout/user:update，并触发三条事件');
}

// ---------- 启动 ----------
function init() {
	// 验证 mitt 是否真正加载（mitt 函数本身存在即为成功）
	if (typeof bus.on === 'function' && typeof bus.emit === 'function') {
		els.status.textContent = 'mitt 已加载 ✓';
		els.status.classList.add('ok');
		appendLog('info', 'mitt 模块加载成功，开始你的事件实验');
	} else {
		els.status.textContent = 'mitt 加载失败 ✗';
		els.status.classList.add('err');
		appendLog('err', 'mitt 模块加载失败，请检查 dist/mitt.mjs 是否可访问');
	}

	els.onBtn.addEventListener('click', () => addHandler(els.onType.value));
	els.onType.addEventListener('keydown', (e) => {
		if (e.key === 'Enter') addHandler(els.onType.value);
	});
	els.offAllBtn.addEventListener('click', clearAllHandlers);

	els.emitBtn.addEventListener('click', emitEvent);
	els.emitType.addEventListener('keydown', (e) => {
		if (e.key === 'Enter') emitEvent();
	});

	els.wildcardToggle.addEventListener('change', (e) => setWildcard(e.target.checked));

	els.clearLogBtn.addEventListener('click', () => {
		els.log.innerHTML = '';
		state.logCounter = 0;
		appendLog('info', '日志已清空（仅清空 DOM 日志面板，未影响订阅）');
	});

	els.sampleBtn.addEventListener('click', runSample);

	renderHandlers();
}

init();