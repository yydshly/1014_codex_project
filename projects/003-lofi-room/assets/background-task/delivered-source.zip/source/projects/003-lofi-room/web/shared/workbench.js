import { TEAM_BY_ID } from "./team.js";

export function workSteps(events = [], actor) {
  const steps = new Map();
  for (const event of events) {
    if (event.type !== "work.activity" || !TEAM_BY_ID[event.actor]) continue;
    const item = event.activity;
    if (!item?.id || (actor && actor !== event.actor)) continue;
    const key = `${event.actor}:${item.id}`;
    steps.set(key, { ...steps.get(key), ...item, actor: event.actor, stage: event.stage, time: event.time });
  }
  return [...steps.values()];
}

// Selection is independent of the narrator and never follows ambient small talk.
export function taskActor(events = [], fallback = "mori") {
  for (let index = events.length - 1; index >= 0; index--) {
    const event = events[index];
    if (event.type === "work.activity" && TEAM_BY_ID[event.actor]) return event.actor;
    if (event.type === "agent.state" && ["working", "reviewing", "testing"].includes(event.status)) return event.actor;
    if (event.type === "revision") return "indigo";
    if (event.type === "run.complete") return "sleepy";
  }
  return fallback;
}

export function workbenchView(snapshot, { actor = "mori", follow = false, stepId = null } = {}) {
  const events = snapshot?.events || [];
  const selected = follow ? taskActor(events, actor) : actor;
  const steps = workSteps(events, selected);
  const activity = (stepId && steps.find((step) => step.id === stepId)) || steps.findLast((step) => step.kind !== "inspect") || steps.at(-1) || null;
  const artifact = snapshot?.artifacts?.findLast((item) => item.actor === selected);
  const task = snapshot?.tasks?.find((item) => item.id === selected || item.actor === selected);
  const last = events.at(-1);
  const live = Boolean(snapshot?.live && !["run.complete", "run.error", "run.cancelled"].includes(last?.type));
  return { actor: selected, member: TEAM_BY_ID[selected], steps, activity, artifact, task,
    live, historical: Boolean(stepId), mode: snapshot?.goal?.mode === "demo" || snapshot?.mode === "demo" ? "demo" : "real",
    delivery: events.findLast((item) => item.type === "run.complete")?.delivery,
    exchanges: events.filter((item) => item.type === "handoff" && [item.from, item.to].includes(selected)).slice(-4) };
}

// Keep the changed region visible instead of showing only the beginning of long files.
export function changedExcerpt(before = "", after = "") {
  const previous = before.split("\n"), next = after.split("\n");
  let start = 0;
  while (start < Math.min(previous.length, next.length) && previous[start] === next[start]) start++;
  const first = Math.max(0, start - 3);
  const excerpt = (lines) => lines.slice(first, first + 36).join("\n").slice(0, 4500);
  return { line: first + 1, before: excerpt(previous), after: excerpt(next) };
}
