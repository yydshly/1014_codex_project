import test from "node:test";
import assert from "node:assert/strict";

test("并行审阅只涉及旧测试且验证已通过时，由验证员交给审阅员复核，不重复开发", async () => {
  const counts = { develop: 0, review: 0, test: 0 };
  const result = await runCollaboration({
    mode: "repository",
    execute: async ({ stage, inputs }) => {
      if (stage in counts) counts[stage]++;
      const reconciled = inputs.some(
        (artifact) =>
          artifact.stage === "test" && artifact.verdict === "approve",
      );
      return {
        title: stage,
        summary: "当前角色已处理实际输入",
        content: "角色复核记录",
        verdict: stage === "review" && !reconciled ? "revise" : "approve",
        data: { fixTarget: stage === "review" ? "tests" : "code" },
      };
    },
  });
  assert.deepEqual(counts, { develop: 1, review: 2, test: 1 });
  assert.ok(
    result.events.some(
      (event) =>
        event.type === "handoff" &&
        event.from === "momo" &&
        event.to === "luna",
    ),
  );
  assert.ok(!result.events.some((event) => event.type === "revision"));
  assert.equal(result.events.at(-1).type, "run.complete");
});
import {
  runCollaboration,
  createDemoExecutor,
  checkPlan,
} from "../shared/workflow.js";

test("协作串联产物依赖，审阅与验证并行，返工后交付", async () => {
  const result = await runCollaboration({ pace: 0 });
  assert.equal(result.artifacts.length, 9);
  const states = result.events.filter((e) => e.type === "agent.state");
  const reviewStart = states.find(
    (e) => e.actor === "luna" && e.status === "reviewing",
  ).seq;
  const testStart = states.find(
    (e) => e.actor === "momo" && e.status === "testing",
  ).seq;
  const firstReviewDone = states.find(
    (e) => e.actor === "luna" && e.status === "blocked",
  ).seq;
  assert.ok(reviewStart < firstReviewDone && testStart < firstReviewDone);
  assert.equal(result.events.filter((e) => e.type === "revision").length, 1);
  const final = result.artifacts.find(
    (a) => a.stage === "develop" && a.revision === 1,
  );
  assert.ok(checkPlan(final.data).every((check) => check.passed));
  const report = result.artifacts.find((a) => a.id === result.reportId);
  assert.equal(report.actor, "sleepy");
  assert.ok(report.inputIds.includes(final.id));
  const ids = new Set(result.artifacts.map((a) => a.id));
  for (const event of result.events.filter((e) => e.type === "handoff"))
    assert.ok(ids.has(event.artifactId));
  assert.equal(result.events.at(-1).type, "run.complete");
});

test("停止后不继续交接或生成下游产物", async () => {
  const controller = new AbortController(),
    events = [];
  await assert.rejects(
    runCollaboration({
      pace: 0,
      signal: controller.signal,
      emit: (event) => {
        events.push(event);
        if (event.type === "artifact") controller.abort();
      },
    }),
    (error) => error.name === "AbortError",
  );
  assert.equal(events.filter((e) => e.type === "artifact").length, 1);
  assert.equal(events.filter((e) => e.type === "handoff").length, 0);
  assert.equal(events.at(-1).type, "run.cancelled");
});

test("语音回放完成后才交接，模型失败不会切换为预设成功", async () => {
  let narrated = 0;
  const events = [];
  await runCollaboration({
    pace: 0,
    narrate: async () => {
      narrated++;
    },
    emit: (event) => {
      events.push(event);
      if (event.type === "handoff") assert.ok(narrated > 0);
    },
  });
  assert.equal(narrated, 10);
  const failures = [];
  await assert.rejects(
    runCollaboration({
      mode: "live",
      execute: async () => {
        throw new Error("模型不可用");
      },
      emit: (e) => failures.push(e),
    }),
    /模型不可用/,
  );
  assert.equal(failures.at(-1).type, "run.error");
  assert.equal(failures.filter((e) => e.type === "artifact").length, 0);
});

test("不完整的模型产物被拒绝，不进入语音或下游", async () => {
  const events = [];
  await assert.rejects(
    runCollaboration({
      mode: "live",
      execute: async () => ({ content: "缺少标题和摘要", verdict: "approve" }),
      emit: (event) => events.push(event),
    }),
    /未提交完整产物/,
  );
  assert.equal(events.filter((event) => event.type === "artifact").length, 0);
  assert.equal(events.filter((event) => event.type === "speech").length, 0);
  assert.equal(events.at(-1).type, "run.error");
});

test("每个真实角色都读取目标验收和白板意见，播报指向下一位伙伴", async () => {
  const context = {
    criteria: ["对话可追踪"],
    notes: ["补充意见转任务单"],
    historicalArtifacts: [
      {
        runId: "previous-run",
        actor: "mori",
        mode: "live",
        title: "上一轮交付",
        summary: "先验收再归档",
        content: "上一轮方案摘要",
      },
    ],
  };
  const actors = [];
  const result = await runCollaboration({
    mode: "live",
    context,
    execute: async ({ role, context: received }) => {
      assert.deepEqual(received, context);
      actors.push(role.id);
      return {
        title: role.name + "提交",
        summary: "请下一位伙伴查看",
        content: "本角色读取验收要求并提出方案。",
        verdict: "approve",
      };
    },
  });
  assert.equal(actors.length, 6);
  const speech = result.events.find((event) => event.type === "speech");
  assert.equal(speech.actor, "mori");
  assert.equal(speech.to, "amber");
});
