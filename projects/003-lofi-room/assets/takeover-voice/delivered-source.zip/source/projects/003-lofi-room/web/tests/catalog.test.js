import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { createCatalogGateway } from "../server/catalog.js";
test("总入口保留项目数据，其他项目同路径可访问，不能读私有文件", async () => {
  const gateway = createCatalogGateway(),
    server = createServer((req, res) =>
      gateway(req, res, () => {
        res.writeHead(404);
        res.end();
      }),
    );
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}/1014_codex_project/`;
  try {
    const home = await fetch(base);
    assert.equal(home.status, 200);
    assert.match(await home.text(), /夜半小屋/);
    const data = await (await fetch(base + "projects.json")).json();
    assert.ok(data.projects.some((p) => p.id === "003"));
    const first = await fetch(base + "001-archify/");
    assert.equal(first.status, 200);
    assert.match(await first.text(), /项目首页/);
    assert.equal(
      (await fetch(base + "projects/003-lofi-room/web/.env.local")).status,
      404,
    );
    assert.equal(
      (await fetch(base + "001-archify/..%2F..%2Fprojects.json")).status,
      403,
    );
  } finally {
    await new Promise((r) => server.close(r));
  }
});

