import { defineConfig } from "vite";
import { collaborationApi } from "./server/api.js";
import { catalogGateway } from "./server/catalog.js";

export default defineConfig({
  base: "/1014_codex_project/003-lofi-room/",
  plugins: [catalogGateway(), collaborationApi()],
  build: {
    chunkSizeWarningLimit: 650,
    rolldownOptions: {
      output: {
        codeSplitting: {
          groups: [
            { name: "three", test: /node_modules[\\/]three[\\/]build[\\/]/ },
          ],
        },
      },
    },
  },
});
