import { TEAM_BY_ID } from "./team.js";

export const DISCUSSION_STATUS = { planning: "角色正在回应修改意见", discussing: "伙伴正在白板前讨论调整", ready: "调整方案已准备好 · 等你点击继续", error: "讨论遇到问题 · 执行仍暂停" };
export function takeoverBoard(snapshot) {
  const control = snapshot?.backendTask?.control || snapshot?.events?.findLast((event) => event.type === "execution.control")?.control;
  const discussion = control?.discussion;
  if (!discussion || discussion.version !== control.version) return null;
  return { ...discussion, paused: control.state === "paused", label: DISCUSSION_STATUS[discussion.status],
    feedback: control.notes.find((note) => note.version === discussion.version)?.text || "",
    names: discussion.participants.map((actor) => TEAM_BY_ID[actor]?.name).filter(Boolean).join("、") };
}
