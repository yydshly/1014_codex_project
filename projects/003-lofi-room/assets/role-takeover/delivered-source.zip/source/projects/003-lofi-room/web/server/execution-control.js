import { randomUUID } from "node:crypto";
import { TEAM_BY_ID } from "../shared/team.js";

const failure = (message, status = 409) => Object.assign(new Error(message), { status });

// A cooperative barrier: running commands finish; no subsequent side effect
// starts while held. It never kills or repeats an in-flight command.
export class ExecutionControl {
  constructor({ signal, changed = async () => {}, redact = (value) => value } = {}) {
    this.signal = signal; this.changed = changed; this.redact = redact;
    this.state = "running"; this.version = 0; this.notes = []; this.operations = new Map(); this.waiters = new Set();
    this.actor = null; this.sealed = false;
  }
  snapshot() {
    return { state: this.state, version: this.version, actor: this.actor, sealed: this.sealed,
      notes: this.notes.map((note) => ({ ...note })), operations: [...this.operations.values()] };
  }
  async publish(reason, note) { await this.changed({ type: "execution.control", reason, control: this.snapshot(), ...(note ? { note } : {}), time: Date.now() }); }
  async checkpoint(signal = this.signal) {
    signal = signal && this.signal && signal !== this.signal ? AbortSignal.any([signal, this.signal]) : signal;
    signal?.throwIfAborted();
    while (this.state !== "running") {
      await new Promise((resolve, reject) => {
        const finish = (error) => { this.waiters.delete(wake); signal?.removeEventListener("abort", abort); error ? reject(error) : resolve(); };
        const wake = () => finish();
        const abort = () => finish(signal.reason);
        this.waiters.add(wake); signal?.addEventListener("abort", abort, { once: true });
      });
      signal?.throwIfAborted();
    }
  }
  async enter(operation, signal) {
    // Recheck after the await: pause can arrive between checkpoint and entry.
    do { await this.checkpoint(signal); } while (this.state !== "running");
    const id = randomUUID(); this.operations.set(id, { ...operation, id });
    return async () => {
      this.operations.delete(id);
      if (this.state === "pausing" && !this.operations.size) { this.state = "paused"; await this.publish("paused"); }
    };
  }
  validate({ actor, version }) {
    this.signal?.throwIfAborted();
    if (this.sealed) throw failure("本轮已进入最终交付，不能再接管；请在成果页提出下一轮反馈。");
    if (!TEAM_BY_ID[actor]) throw failure("请选择有效角色。", 400);
    if (!Number.isSafeInteger(version) || version !== this.version) throw failure("修改版本已更新，请核对最新意见后重试。");
  }
  async pause(input) {
    this.validate(input);
    if (this.state !== "running") return this.snapshot();
    this.actor = input.actor; this.state = this.operations.size ? "pausing" : "paused";
    await this.publish(this.state); return this.snapshot();
  }
  async feedback(input) {
    this.validate(input);
    if (this.state !== "paused") throw failure("请等当前操作完成并进入执行暂停后，再提交修改意见。");
    if (typeof input.text !== "string" || !input.text.trim() || input.text.trim().length > 2000) throw failure("修改意见需为1至2000字。", 400);
    if (this.notes.length >= 20) throw failure("本轮修改意见已达20条，请整理后在下一轮继续。");
    this.actor = input.actor;
    const note = { id: randomUUID(), actor: input.actor, text: this.redact(input.text.trim()), version: ++this.version, time: Date.now() };
    this.notes.push(note); await this.publish("feedback", note); return this.snapshot();
  }
  async resume(input) {
    this.validate(input);
    if (this.state !== "paused") throw failure("任务尚未进入执行暂停，不能继续。");
    this.state = "running"; await this.publish("resumed");
    for (const wake of [...this.waiters]) wake();
    return this.snapshot();
  }
  instructions() {
    return this.notes.length ? "\n使用者在同一任务执行中提交的修改意见（保留原目标、原验收及测试保护；新意见必须落到实际工作，不能只口头答应）：\n" + this.notes.map((note) => `[修改${note.version}，关注${TEAM_BY_ID[note.actor].name}] ${note.text}`).join("\n") : "";
  }
  seal(version) {
    if (this.state !== "running" || version !== this.version) throw failure("用户修改尚未经过重新验证，禁止交付。");
    this.sealed = true;
  }
}
