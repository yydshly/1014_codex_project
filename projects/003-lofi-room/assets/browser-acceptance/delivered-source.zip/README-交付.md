# 原仓库交付

来源：https://github.com/yydshly/1014_codex_project
固定版本：2963155d86743457b5825d2e0b09c237dc976c3b
许可证：保留仓库与003依赖的原许可证，未声明统一仓库许可

本机独立目录克隆并修改原仓库，运行原有构建与测试后启动 Demo；当前用户权限，无系统隔离

打开：http://127.0.0.1:64707/1014_codex_project/003-lofi-room/?view=workspace
有效期至：2026-10-20T05:05:02.956Z

源码位于 source/；依赖未打包。运行时：Node v22.15.0。请使用交付清单runtime记录的版本，在source下对应子项目目录执行 npm ci、npm run build、npm test。库项目静态Demo可在解压目录执行 python -m http.server 8080 --directory source，再打开对应Demo路径。实际命令和完整stdout/stderr位于evidence/commands.json；构建、测试、原测试文件完整性及HTTP验证结果均来自执行器。

验证范围：原依赖安装、build/test退出码、测试保护、HTTP可达性，以及所列原始需求的浏览器操作与断言；保留人工体验验收
